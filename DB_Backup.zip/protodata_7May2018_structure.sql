/*
SQLyog Enterprise Trial - MySQL GUI v7.11 
MySQL - 5.5.5-10.1.19-MariaDB : Database - apidata
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`apidata` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `apidata`;

/*Table structure for table `amazon_denorm_table` */

DROP TABLE IF EXISTS `amazon_denorm_table`;

CREATE TABLE `amazon_denorm_table` (
  `pk_amz_denorm_table` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `productId` varbinary(50) DEFAULT NULL,
  `title` longtext,
  `description` longtext,
  `imageUrlStr` longtext,
  `mrp` longtext,
  `sellingPrice` varchar(20) DEFAULT NULL,
  `specialPrice` varchar(20) DEFAULT NULL,
  `productUrl` longtext,
  `categories` longtext,
  `productBrand` varbinary(100) DEFAULT NULL,
  `productFamily` varbinary(100) DEFAULT NULL,
  `inStock` varchar(10) DEFAULT NULL,
  `codAvailable` varchar(10) DEFAULT NULL,
  `offers` longtext,
  `discount` varchar(30) DEFAULT NULL,
  `shippingCharges` varchar(30) DEFAULT NULL,
  `deliveryTime` varchar(255) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `sizeUnit` varchar(20) DEFAULT NULL,
  `storage` varchar(30) DEFAULT NULL,
  `displaySize` varchar(30) DEFAULT NULL,
  `keySpecsStr` longtext,
  `detailedSpecsStr` longtext,
  `specificationList` longtext,
  `sellerName` varbinary(255) DEFAULT NULL,
  `sellerAverageRating` varchar(20) DEFAULT NULL,
  `sellerNoOfRatings` varchar(20) DEFAULT NULL,
  `sellerNoOfReviews` varchar(20) DEFAULT NULL,
  `sleeve` varchar(20) DEFAULT NULL,
  `neck` varchar(20) DEFAULT NULL,
  `idealFor` varbinary(255) DEFAULT NULL,
  PRIMARY KEY (`pk_amz_denorm_table`),
  KEY `fk_seller_id` (`sellerName`),
  KEY `fk_brand_id` (`productBrand`),
  KEY `fk_sku_id` (`productId`),
  KEY `fk_category_id` (`fk_category_id`),
  KEY `title` (`title`(255))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `amz_denorm_table_xml` */

DROP TABLE IF EXISTS `amz_denorm_table_xml`;

CREATE TABLE `amz_denorm_table_xml` (
  `pk_amz_denorm_table` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `item_unique_id` varbinary(100) NOT NULL,
  `item_title` text NOT NULL,
  `item_long_desc` text,
  `item_category` varbinary(255) DEFAULT NULL,
  `item_condition` varbinary(255) DEFAULT NULL,
  `item_brand` varbinary(255) DEFAULT NULL,
  `amzn_page_url` varbinary(255) DEFAULT NULL,
  `item_image_url_small` varbinary(255) DEFAULT NULL,
  `item_image_url` varbinary(255) DEFAULT NULL,
  `item_image_url_large` varbinary(255) DEFAULT NULL,
  `list_price` varbinary(50) DEFAULT NULL,
  `item_price` varbinary(50) DEFAULT NULL,
  PRIMARY KEY (`pk_amz_denorm_table`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `flipkart_api_data` */

DROP TABLE IF EXISTS `flipkart_api_data`;

CREATE TABLE `flipkart_api_data` (
  `pk_flp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `desc` longtext,
  `fk_sku_id` bigint(20) unsigned NOT NULL,
  `imageStr` longtext,
  `maxPrice` varchar(50) DEFAULT NULL,
  `flpPrice` varchar(50) DEFAULT NULL,
  `flpSplPrice` varchar(50) DEFAULT NULL,
  `productUrl` varchar(255) DEFAULT NULL,
  `fk_brand_id` int(11) unsigned DEFAULT NULL,
  `inStock` enum('Yes','No') DEFAULT NULL,
  `cod` enum('Yes','No') DEFAULT NULL,
  `discPerc` varchar(100) DEFAULT NULL,
  `offers` varchar(255) DEFAULT NULL,
  `shipping` varchar(50) DEFAULT NULL,
  `deliveryTime` varchar(255) DEFAULT NULL,
  `fk_seller_id` bigint(20) unsigned NOT NULL,
  `sellerRating` float unsigned DEFAULT NULL,
  `noOfRatings` int(11) unsigned DEFAULT NULL,
  `noOfReviews` int(11) unsigned DEFAULT NULL,
  `fk_flp_data_fetch_id` int(11) unsigned NOT NULL,
  `fk_category_id` int(11) unsigned NOT NULL,
  `Currency` enum('Rs','$') NOT NULL DEFAULT 'Rs',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_flp_id`),
  KEY `fk_flp_category_id` (`fk_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `flipkart_api_data_23march2018` */

DROP TABLE IF EXISTS `flipkart_api_data_23march2018`;

CREATE TABLE `flipkart_api_data_23march2018` (
  `pk_flp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `productId` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `image200` varchar(255) DEFAULT NULL,
  `maxPrice` varchar(50) DEFAULT NULL,
  `flpPrice` varchar(50) DEFAULT NULL,
  `flpSplPrice` varchar(50) DEFAULT NULL,
  `productUrl` varchar(255) DEFAULT NULL,
  `fk_brand_id` int(11) unsigned DEFAULT NULL,
  `inStock` enum('Yes','No') DEFAULT NULL,
  `cod` enum('Yes','No') DEFAULT NULL,
  `discPerc` varchar(100) DEFAULT NULL,
  `offers` varchar(255) DEFAULT NULL,
  `shipping` varchar(50) DEFAULT NULL,
  `deliveryTime` varchar(255) DEFAULT NULL,
  `sellerName` varchar(255) DEFAULT NULL,
  `sellerRating` float unsigned DEFAULT NULL,
  `noOfRatings` int(11) unsigned DEFAULT NULL,
  `noOfReviews` int(11) unsigned DEFAULT NULL,
  `fk_flp_data_fetch_id` int(11) unsigned NOT NULL,
  `fk_category_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`pk_flp_id`),
  KEY `title` (`title`),
  KEY `image200` (`image200`),
  KEY `flpPrice` (`flpPrice`),
  KEY `flpSplPrice` (`flpSplPrice`),
  KEY `productUrl` (`productUrl`),
  KEY `inStock` (`inStock`),
  KEY `cod` (`cod`),
  KEY `discPerc` (`discPerc`),
  KEY `offers` (`offers`),
  KEY `shipping` (`shipping`),
  KEY `deliveryTime` (`deliveryTime`),
  KEY `sellerName` (`sellerName`),
  KEY `sellerRating` (`sellerRating`),
  KEY `noratings` (`noOfRatings`),
  KEY `noReviews` (`noOfReviews`),
  KEY `fk_flp_category_id` (`fk_category_id`),
  KEY `productId` (`productId`),
  KEY `image` (`image`),
  KEY `fk_brand_id` (`fk_brand_id`),
  KEY `fk_flp_data_fetch_id` (`fk_flp_data_fetch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20975 DEFAULT CHARSET=latin1;

/*Table structure for table `flipkart_denorm_table` */

DROP TABLE IF EXISTS `flipkart_denorm_table`;

CREATE TABLE `flipkart_denorm_table` (
  `pk_flk_denorm_table` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `productId` varbinary(50) DEFAULT NULL,
  `title` longtext,
  `description` longtext,
  `imageUrlStr` longtext,
  `mrp` longtext,
  `sellingPrice` varchar(20) DEFAULT NULL,
  `specialPrice` varchar(20) DEFAULT NULL,
  `productUrl` longtext,
  `categories` longtext,
  `productBrand` varbinary(100) DEFAULT NULL,
  `productFamily` varbinary(100) DEFAULT NULL,
  `inStock` varchar(10) DEFAULT NULL,
  `codAvailable` varchar(10) DEFAULT NULL,
  `offers` longtext,
  `discount` varchar(30) DEFAULT NULL,
  `shippingCharges` varchar(30) DEFAULT NULL,
  `deliveryTime` varchar(255) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `sizeUnit` varchar(20) DEFAULT NULL,
  `storage` varchar(30) DEFAULT NULL,
  `displaySize` varchar(30) DEFAULT NULL,
  `keySpecsStr` longtext,
  `detailedSpecsStr` longtext,
  `specificationList` longtext,
  `sellerName` varbinary(255) DEFAULT NULL,
  `sellerAverageRating` varchar(20) DEFAULT NULL,
  `sellerNoOfRatings` varchar(20) DEFAULT NULL,
  `sellerNoOfReviews` varchar(20) DEFAULT NULL,
  `sleeve` varchar(20) DEFAULT NULL,
  `neck` varchar(20) DEFAULT NULL,
  `idealFor` varbinary(255) DEFAULT NULL,
  PRIMARY KEY (`pk_flk_denorm_table`),
  KEY `fk_seller_id` (`sellerName`),
  KEY `fk_brand_id` (`productBrand`),
  KEY `fk_sku_id` (`productId`),
  KEY `fk_category_id` (`fk_category_id`),
  KEY `title` (`title`(255))
) ENGINE=InnoDB AUTO_INCREMENT=14520735 DEFAULT CHARSET=latin1;

/*Table structure for table `flipkart_denorm_table_copy` */

DROP TABLE IF EXISTS `flipkart_denorm_table_copy`;

CREATE TABLE `flipkart_denorm_table_copy` (
  `pk` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `productId` longtext,
  `title` longtext,
  `description` longtext,
  `imageUrlStr` longtext,
  `mrp` longtext,
  `sellingPrice` longtext,
  `specialPrice` longtext,
  `productUrl` longtext,
  `categories` longtext,
  `productBrand` longtext,
  `productFamily` longtext,
  `inStock` longtext,
  `codAvailable` longtext,
  `offers` longtext,
  `discount` longtext,
  `shippingCharges` longtext,
  `deliveryTime` longtext,
  `size` longtext,
  `color` longtext,
  `sizeUnit` longtext,
  `storage` longtext,
  `displaySize` longtext,
  `keySpecsStr` longtext,
  `detailedSpecsStr` longtext,
  `specificationList` longtext,
  `sellerName` longtext,
  `sellerAverageRating` longtext,
  `sellerNoOfRatings` longtext,
  `sellerNoOfReviews` longtext,
  `sleeve` longtext,
  `neck` longtext,
  `idealFor` longtext,
  PRIMARY KEY (`pk`),
  KEY `fk_seller_id` (`sellerName`(255)),
  KEY `fk_brand_id` (`productBrand`(255)),
  KEY `fk_sku_id` (`productId`(255))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `oss_amz_data_fetch_cron_log_master_zip` */

DROP TABLE IF EXISTS `oss_amz_data_fetch_cron_log_master_zip`;

CREATE TABLE `oss_amz_data_fetch_cron_log_master_zip` (
  `pk_amz_data_import_log_zip_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_url_id` bigint(20) unsigned NOT NULL,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `fk_cron_id` bigint(20) unsigned NOT NULL,
  `fk_file_path_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` enum('In Queue','Unzipped','Imported','Failed') NOT NULL DEFAULT 'In Queue',
  PRIMARY KEY (`pk_amz_data_import_log_zip_id`),
  KEY `fk_url_id` (`fk_url_id`),
  KEY `fk_category_id` (`fk_category_id`),
  KEY `fk_cron_id` (`fk_cron_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `status` (`status`),
  KEY `fk_file_path_id` (`fk_file_path_id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_amz_data_fetch_cron_master` */

DROP TABLE IF EXISTS `oss_amz_data_fetch_cron_master`;

CREATE TABLE `oss_amz_data_fetch_cron_master` (
  `pk_amz_data_fetch_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `day_count` int(11) unsigned NOT NULL,
  PRIMARY KEY (`pk_amz_data_fetch_id`),
  KEY `start_time` (`start_time`),
  KEY `end_time` (`end_time`),
  KEY `day_count` (`day_count`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_amz_file_import_log` */

DROP TABLE IF EXISTS `oss_amz_file_import_log`;

CREATE TABLE `oss_amz_file_import_log` (
  `pk_file_import_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_cron_id` bigint(20) unsigned NOT NULL,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`pk_file_import_log_id`),
  KEY `fk_cron_id` (`fk_cron_id`),
  KEY `fk_category_id` (`fk_category_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_amz_file_unzip_log` */

DROP TABLE IF EXISTS `oss_amz_file_unzip_log`;

CREATE TABLE `oss_amz_file_unzip_log` (
  `pk_file_unzip_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_cron_id` bigint(20) unsigned NOT NULL,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`pk_file_unzip_log_id`),
  KEY `fk_cron_id` (`fk_cron_id`),
  KEY `fk_category_id` (`fk_category_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_brand_master` */

DROP TABLE IF EXISTS `oss_brand_master`;

CREATE TABLE `oss_brand_master` (
  `pk_brand_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `brand` varbinary(255) NOT NULL,
  `fk_user_id` int(11) unsigned NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Enabled','Disabled') NOT NULL DEFAULT 'Enabled',
  PRIMARY KEY (`pk_brand_id`),
  UNIQUE KEY `brand` (`brand`),
  KEY `fk_user_id` (`fk_user_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=45170 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_category_master` */

DROP TABLE IF EXISTS `oss_category_master`;

CREATE TABLE `oss_category_master` (
  `pk_category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `fk_user_id` int(11) unsigned NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Enabled','Disabled') NOT NULL DEFAULT 'Enabled',
  PRIMARY KEY (`pk_category_id`),
  UNIQUE KEY `category` (`category`),
  KEY `fk_user_id` (`fk_user_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_file_path_master` */

DROP TABLE IF EXISTS `oss_file_path_master`;

CREATE TABLE `oss_file_path_master` (
  `pk_file_path_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_path` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`pk_file_path_id`),
  KEY `url` (`file_path`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4984 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_flp_data_fetch_cron_log_master_zip` */

DROP TABLE IF EXISTS `oss_flp_data_fetch_cron_log_master_zip`;

CREATE TABLE `oss_flp_data_fetch_cron_log_master_zip` (
  `pk_flp_data_import_log_zip_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_url_id` bigint(20) unsigned NOT NULL,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `fk_cron_id` bigint(20) unsigned NOT NULL,
  `fk_file_path_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` enum('In Queue','Unzipped','Imported','Failed') NOT NULL DEFAULT 'In Queue',
  PRIMARY KEY (`pk_flp_data_import_log_zip_id`),
  KEY `fk_url_id` (`fk_url_id`),
  KEY `fk_category_id` (`fk_category_id`),
  KEY `fk_cron_id` (`fk_cron_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `status` (`status`),
  KEY `fk_file_path_id` (`fk_file_path_id`)
) ENGINE=InnoDB AUTO_INCREMENT=413 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_flp_data_fetch_cron_master` */

DROP TABLE IF EXISTS `oss_flp_data_fetch_cron_master`;

CREATE TABLE `oss_flp_data_fetch_cron_master` (
  `pk_flp_data_fetch_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `day_count` int(11) unsigned NOT NULL,
  PRIMARY KEY (`pk_flp_data_fetch_id`),
  KEY `start_time` (`start_time`),
  KEY `end_time` (`end_time`),
  KEY `day_count` (`day_count`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_flp_file_import_log` */

DROP TABLE IF EXISTS `oss_flp_file_import_log`;

CREATE TABLE `oss_flp_file_import_log` (
  `pk_file_import_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_cron_id` bigint(20) unsigned NOT NULL,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`pk_file_import_log_id`),
  KEY `fk_cron_id` (`fk_cron_id`),
  KEY `fk_category_id` (`fk_category_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_flp_file_unzip_log` */

DROP TABLE IF EXISTS `oss_flp_file_unzip_log`;

CREATE TABLE `oss_flp_file_unzip_log` (
  `pk_file_unzip_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_cron_id` bigint(20) unsigned NOT NULL,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`pk_file_unzip_log_id`),
  KEY `fk_cron_id` (`fk_cron_id`),
  KEY `fk_category_id` (`fk_category_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_sc_data_fetch_cron_log_master_zip` */

DROP TABLE IF EXISTS `oss_sc_data_fetch_cron_log_master_zip`;

CREATE TABLE `oss_sc_data_fetch_cron_log_master_zip` (
  `pk_sc_data_import_log_zip_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_url_id` bigint(20) unsigned NOT NULL,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `fk_cron_id` bigint(20) unsigned NOT NULL,
  `fk_file_path_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` enum('In Queue','Unzipped','Imported','Failed') NOT NULL DEFAULT 'In Queue',
  PRIMARY KEY (`pk_sc_data_import_log_zip_id`),
  KEY `fk_url_id` (`fk_url_id`),
  KEY `fk_category_id` (`fk_category_id`),
  KEY `fk_cron_id` (`fk_cron_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `status` (`status`),
  KEY `fk_file_path_id` (`fk_file_path_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_sc_data_fetch_cron_master` */

DROP TABLE IF EXISTS `oss_sc_data_fetch_cron_master`;

CREATE TABLE `oss_sc_data_fetch_cron_master` (
  `pk_sc_data_fetch_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `day_count` int(11) unsigned NOT NULL,
  PRIMARY KEY (`pk_sc_data_fetch_id`),
  KEY `start_time` (`start_time`),
  KEY `end_time` (`end_time`),
  KEY `day_count` (`day_count`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_sc_file_import_log` */

DROP TABLE IF EXISTS `oss_sc_file_import_log`;

CREATE TABLE `oss_sc_file_import_log` (
  `pk_file_import_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_cron_id` bigint(20) unsigned NOT NULL,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`pk_file_import_log_id`),
  KEY `fk_cron_id` (`fk_cron_id`),
  KEY `fk_category_id` (`fk_category_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_sc_file_unzip_log` */

DROP TABLE IF EXISTS `oss_sc_file_unzip_log`;

CREATE TABLE `oss_sc_file_unzip_log` (
  `pk_file_unzip_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_cron_id` bigint(20) unsigned NOT NULL,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`pk_file_unzip_log_id`),
  KEY `fk_cron_id` (`fk_cron_id`),
  KEY `fk_category_id` (`fk_category_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_seller_master` */

DROP TABLE IF EXISTS `oss_seller_master`;

CREATE TABLE `oss_seller_master` (
  `pk_seller_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `seller` varbinary(255) NOT NULL,
  `fk_user_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` enum('Enabled','Disabled') NOT NULL DEFAULT 'Enabled',
  PRIMARY KEY (`pk_seller_id`),
  UNIQUE KEY `seller_name` (`seller`),
  KEY `fk_user_id` (`fk_user_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=22832 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_sku_master` */

DROP TABLE IF EXISTS `oss_sku_master`;

CREATE TABLE `oss_sku_master` (
  `pk_sku_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sku` varchar(255) NOT NULL,
  `fk_user_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` enum('Enabled','Disabled') NOT NULL DEFAULT 'Enabled',
  PRIMARY KEY (`pk_sku_id`),
  UNIQUE KEY `sku` (`sku`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `status` (`status`),
  KEY `fk_user_id` (`fk_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11535137 DEFAULT CHARSET=latin1;

/*Table structure for table `oss_url_master` */

DROP TABLE IF EXISTS `oss_url_master`;

CREATE TABLE `oss_url_master` (
  `pk_url_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(1000) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`pk_url_id`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `url` (`url`(767))
) ENGINE=InnoDB AUTO_INCREMENT=7767 DEFAULT CHARSET=latin1;

/*Table structure for table `shopclues_denorm_table` */

DROP TABLE IF EXISTS `shopclues_denorm_table`;

CREATE TABLE `shopclues_denorm_table` (
  `pk_shopclues_data` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fk_category_id` bigint(20) unsigned NOT NULL,
  `id` bigint(20) unsigned NOT NULL,
  `title` varbinary(255) DEFAULT NULL,
  `description` text,
  `link` varbinary(255) DEFAULT NULL,
  `image_link` varbinary(255) DEFAULT NULL,
  `condition` varbinary(15) DEFAULT NULL,
  `availability` varbinary(15) DEFAULT NULL,
  `price` int(11) unsigned NOT NULL,
  `brand` varbinary(100) DEFAULT NULL,
  `google_product_category` varbinary(200) DEFAULT NULL,
  `sale_price` int(11) unsigned NOT NULL,
  `product_type` varbinary(255) DEFAULT NULL,
  `ios_url` varbinary(255) DEFAULT NULL,
  `ios_app_store_id` int(11) unsigned NOT NULL,
  `ios_app_name` varbinary(25) DEFAULT NULL,
  `iphone_url` varbinary(255) DEFAULT NULL,
  `iphone_app_store_id` int(11) unsigned NOT NULL,
  `iphone_app_name` varbinary(25) DEFAULT NULL,
  `android_url` varbinary(255) DEFAULT NULL,
  `android_package` varbinary(30) DEFAULT NULL,
  `android_app_name` varbinary(30) DEFAULT NULL,
  `windows_phone_url` varbinary(255) DEFAULT NULL,
  `windows_phone_app_id` varbinary(255) DEFAULT NULL,
  `windows_phone_app_name` varbinary(30) DEFAULT NULL,
  `custom_label_0` varbinary(30) DEFAULT NULL,
  `custom_label_1` varbinary(30) DEFAULT NULL,
  `custom_label_2` varbinary(30) DEFAULT NULL,
  `custom_label_3` varbinary(30) DEFAULT NULL,
  PRIMARY KEY (`pk_shopclues_data`)
) ENGINE=InnoDB AUTO_INCREMENT=2949076 DEFAULT CHARSET=latin1;

/*Table structure for table `shopclues_denorm_table_copy` */

DROP TABLE IF EXISTS `shopclues_denorm_table_copy`;

CREATE TABLE `shopclues_denorm_table_copy` (
  `pk_shopclues_data` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id` bigint(20) unsigned NOT NULL,
  `title` varbinary(255) DEFAULT NULL,
  `description` text,
  `link` varbinary(255) DEFAULT NULL,
  `image_link` varbinary(255) DEFAULT NULL,
  `condition` varbinary(15) DEFAULT NULL,
  `availability` varbinary(15) DEFAULT NULL,
  `price` int(11) unsigned NOT NULL,
  `brand` varbinary(100) DEFAULT NULL,
  `google_product_category` varbinary(200) DEFAULT NULL,
  `sale_price` int(11) unsigned NOT NULL,
  `product_type` varbinary(255) DEFAULT NULL,
  `ios_url` varbinary(255) DEFAULT NULL,
  `ios_app_store_id` int(11) unsigned NOT NULL,
  `ios_app_name` varbinary(25) DEFAULT NULL,
  `iphone_url` varbinary(255) DEFAULT NULL,
  `iphone_app_store_id` int(11) unsigned NOT NULL,
  `iphone_app_name` varbinary(25) DEFAULT NULL,
  `android_url` varbinary(255) DEFAULT NULL,
  `android_package` varbinary(30) DEFAULT NULL,
  `android_app_name` varbinary(30) DEFAULT NULL,
  `windows_phone_url` varbinary(255) DEFAULT NULL,
  `windows_phone_app_id` varbinary(255) DEFAULT NULL,
  `windows_phone_app_name` varbinary(30) DEFAULT NULL,
  `custom_label_0` varbinary(30) DEFAULT NULL,
  `custom_label_1` varbinary(30) DEFAULT NULL,
  `custom_label_2` varbinary(30) DEFAULT NULL,
  `custom_label_3` varbinary(30) DEFAULT NULL,
  PRIMARY KEY (`pk_shopclues_data`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Table structure for table `srv_user_master` */

DROP TABLE IF EXISTS `srv_user_master`;

CREATE TABLE `srv_user_master` (
  `pk_user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `password` varchar(150) NOT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `mobile_number` bigint(12) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `designation` enum('Normal','HR') DEFAULT 'Normal',
  `status` enum('Enabled','Disabled') NOT NULL DEFAULT 'Enabled',
  PRIMARY KEY (`pk_user_id`),
  KEY `fname` (`fname`),
  KEY `lname` (`lname`),
  KEY `status` (`status`),
  KEY `fk_mobile_id` (`mobile_number`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`),
  KEY `password` (`password`),
  KEY `remember_token` (`remember_token`),
  KEY `designation` (`designation`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
